document.addEventListener("DOMContentLoaded", () => {
  const signupForm = document.querySelector("form");

  signupForm.addEventListener("submit", (e) => {
    e.preventDefault();

    const firstName = signupForm.querySelector('input[placeholder="First Name"]').value.trim();
    const surname = signupForm.querySelector('input[placeholder="Surname"]').value.trim();
    const email = signupForm.querySelector('input[placeholder="Email or Phone"]').value.trim();
    const password = signupForm.querySelector('input[placeholder="Password"]').value.trim();
    const address = signupForm.querySelector('input[placeholder="Address"]').value.trim();
    const city = signupForm.querySelector('input[placeholder="City"]').value.trim();
    const state = signupForm.querySelector('input[placeholder="State"]').value.trim();
    const country = signupForm.querySelector('input[placeholder="Country"]').value.trim();

    // Validation
    if (!firstName || !surname || !email || !password) {
      alert("Please fill all required fields.");
      return;
    }

    // Check if user already exists
    const existingUser = JSON.parse(localStorage.getItem(email));
    if (existingUser) {
      alert("User already exists! Please login instead.");
      return;
    }

    // Save user data
    const userData = { firstName, surname, email, password, address, city, state, country };
    localStorage.setItem(email, JSON.stringify(userData));

    alert("Signup successful! Redirecting to login page...");
    window.location.href = "login.html";
  });
});
