// login.js

document.addEventListener("DOMContentLoaded", () => {
  const loginForm = document.querySelector("form");

  loginForm.addEventListener("submit", (e) => {
    e.preventDefault();

    const email = loginForm.querySelector('input[name="email"]').value.trim();
    const password = loginForm.querySelector('input[name="password"]').value.trim();

    if (!email || !password) {
      alert("Please enter both email and password.");
      return;
    }

    const userData = JSON.parse(localStorage.getItem(email));

    if (!userData) {
      alert("No account found with this email. Please sign up first.");
      return;
    }

    if (userData.password !== password) {
      alert("Incorrect password. Please try again.");
      return;
    }

    // Successful login
    alert(`Welcome back, ${userData.firstName}!`);
    localStorage.setItem("loggedInUser", JSON.stringify(userData));

    // Redirect to homepage or dashboard
    window.location.href = "index.html";
  });
});
